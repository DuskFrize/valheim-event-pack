# 1.2.16
* simplified upgrade handling to return only an existing replacement item to its original extra slot
* removed upgrade outcome marker checks that could interrupt mod initialization when another mod changes crafting
* removed upgrade-specific rollback, deferred recovery, capacity bypasses and automatic re-equipping

# 1.2.15
* fixed custom-slot auto-equip items preventing automatic tombstone recovery even when the contents fit
* tombstone weight checks now omit uncertain equipment bonuses instead of rejecting all recovery, while accounting for possible loss of current equipment bonuses
* mutually exclusive utility items no longer block automatic tombstone recovery when their uncertain bonuses are not needed
* fixed initial hotbar selection bypassing UI input blocking
* fixed extra hotbar shortcut labels briefly changing to vanilla numbers when the input layout changes

# 1.2.14
* fixed quick-slot hotbars disappearing during auto pickup with AdventureBackpacks and other inventory capacity checks
* fixed occupied extra slots being reported as free during nested inventory capacity checks

# 1.2.13
* fixed Mouse3 and Mouse4 in keyboard shortcut combinations

# 1.2.12
* fixed backup recovery being blocked when one item prefab is unavailable
* unavailable backup items are preserved for later recovery without restoring already recovered items again
* normal slot backups keep updating while unavailable items remain pending

# 1.2.11
* patch 1.0.15

# 1.2.10
* ServerManager compatibility

# 1.2.9
* fixed cheated items stacking with each other

# 1.2.8
* fixed stack all prevention

# 1.2.7
* removed obsolete with ZenBeeHive
* patch 1.0.14

# 1.2.6
* fixed compatibility with Jewelcrafting and other mods that replace crafting, so intentionally destroyed items in ExtraSlots are not restored

# 1.2.5
* fixed ServerCharacters compatibility so food, ammo, quick-slot and other ExtraSlots items keep their slot placement across reconnects

# 1.2.4
* updated compatibility with ValheimPlus 0.10.1.1 and newer

# 1.2.3
* patch 1.0.12

# 1.2.2
* Reduced idle hotkey processing by checking keys before slot, inventory and UI state.
* Reused registered hotbar slot layouts and removed repeated hotbar item/action scans and redundant queued-equipment passes.

# 1.2.1
* fixed loading older worlds containing items saved in extra slots
* prevented duplicated recovered stacks after an interrupted recovery merge
* extra utility items now respect normal equip restrictions, including broken durability
* improved quiver arrow lookup when no ammunition is equipped and after changing characters
* updated for Valheim 1.0.7
* extra slots and items are preserved when the game changes the character's inventory size; additional rows now follow the native inventory size
* improved recovery of old and new character, backup, and migrated inventory saves
* upgrading slotted equipment now handles successful upgrades, quality reductions, and intentional destruction correctly
* crafted items and returned materials dropped from a full inventory retain their stack size, quality, variant, and custom data
* improved tombstone item persistence and recovery when container ownership changes in multiplayer
* updated inventory selection, equipment indicators, and touch interaction with extra hotbars

# 1.2.0
* significantly strengthened item-loss prevention when inventory rows, slot availability, or mod setup changes; items that cannot be placed safely are preserved and restored when a valid destination becomes available
* deferred items survive character saves, temporarily missing item prefabs, and running the character without ExtraSlots before returning to the mod
* improved tombstone recovery, including safer full-loot checks, preservation of deferred items in graves, and optional auto-equip after using Take All
* improved migration and recovery from EquipmentAndQuickSlots 2.x/3.x, ComfyQuickSlots and InventorySlots
* optimized hotbar updates
* added independent options to keep empty available Quick, Ammo, and Food hotbar slots visible
* the equipment panel can now be repositioned by dragging and optionally snapped to its default position or nearby inventory UI edges
* added an option to fade the queued equip indicator as the current equip action progresses
* added an option to keep the equipped state of items that are kept on death

# 1.1.21
* updated Epic Loot compatibility for legacy versions and the 0.13.0+ API, including magic effects, set bonuses, and sacrifice filtering in extra slots

# 1.1.20
* some configs made unconditionally server controlled

# 1.1.19
* hotkeys handling optimizations and fixes
* migrated configuration synchronization from ServerSync to ConditionalConfigSync
* server administrators can override the ownership of policy-controlled settings through ConditionalConfigSync policy

# 1.1.18
* new config "Custom slot items can use regular equipment slots", disabled by default. Custom items go into custom slots only by default.

# 1.1.17
* improved items in extra slots from being lost of moved into a grave on death in certain scenarios

# 1.1.16
* fixed compatibility with balrond_Runeforging and potentially other mods changing inventory items visuals
* minor optimizations

# 1.1.15
* fixed lost compatibility with PlantEasily overriding gamepad input

# 1.1.14
* fixed on death issue and upgraded code for extra utility slots

# 1.1.13
* fixed custom item lists in several configs not applied initially if set up with prefab names
* minor optimizations here and there

# 1.1.12
* fixed rare issue with this mod allowing adding to an extra slot an item that was declined by another mod

# 1.1.11
* hotbar visibility for quick, ammo, and food slots is now server-synced

# 1.1.10
* fixed hotkeys issues, final optimizations

# 1.1.9
* minor optimizations to hotkey usage and similar hotkey prevention

# 1.1.8
* fixed ZenBeehive compat
* minor fixes

# 1.1.7
* patch 0.221.10

# 1.1.6
* fixed hovers for custom slot items making backpacks unusable in certain circumstances

# 1.1.5
* changed behaviour of "fixed item list" in "Death tweaks" section to always keep configured items regardless of group configs "Keep items at X slots".

# 1.1.4
* item weight reduction percent in slots tooltip (if set)
* a bit more compatible CanAddItem algorithm with support of absurdly high item stack sizes causing signed integer overflow
* fixed mod breaking on startup if localization file is incorrect
* fixed vanilla slots reordering not working properly

# 1.1.3
* new config for Death Tweaks and Tombstone Auto Equip - item list. You can set your custom items to be kept on death or auto equipped
* Infused Megingjord from NorseDemigods added to unique-equipped items along with other belts increasing carry weight
* added support of equippable items with custom "increase carry weight" algorithms (like said Infused Megingjord from NorseDemigods)
* items auto equip after tombstone pickup was improved a bit for better support of mods altering respawning or tombstone interaction (like Afterdeath and Resurrection)

# 1.1.2
* fixed item icons in lightened slot visuals (less saturated and less size)
* new configs to show/hide lightened slots background icon and tooltip

# 1.1.1
* fixed issue with progression based on item name not working in some cases

# 1.1.0
* more translations and current translations polished a bit
* new feature: lightened slots. Make regular inventory rows to have reduced item weight. By default config is set for last two extra inventory rows to have item weight reduction. You can configure extra inventory rows to work as kinda embedded backpack upgraded on boss kills. If you are interested but confused by configs pls feel free to contact me at discord.
* new config: black lists for items in food, ammo, misc slots
* fixed mouse side buttons not available to bind
* increased performance when looking at Fermenter with AzuCraftyBoxes and BowBeforeHoes enabled

# 1.0.51
* rehauled approach to repositioning of side panels with reduced inventory size

# 1.0.50
* items from quick, ammo and food slots are now shown at [ValheimRadial](https://thunderstore.io/c/valheim/p/PerspectiveBroad4501/ValheimRadial/) menu (disableable at Mods compatibility - Valheim Radial)

# 1.0.49
* ZenUI assigned gear slots compatibility
* fixed potential loss of Jewelcrafting extended tooltip

# 1.0.48
* extra rows amount can now be set up to -3 to reduce regular inventory size
* added new configs for regular inventory rows progression
* items in extra utility slots made visible on player (disableable in config)

# 1.0.47
* you can now use prefab names instead of item names ($item_...). For example BeltStrength instead of $item_beltstrength
* changed default values of configs related to changes in item name -> prefab name. Previously configurated values still work.
* fixed wrong state of player inventory after obtaining player unique key expanding extra inventory rows (like when you get Forsaken Power first time and that Forsaken Power was supposed to add inventory row)

# 1.0.46
* maximum amount of custom slots increased to 16 to support used defined custom slots from ExtraSlotsCustomSlots

# 1.0.45
* RequipMe compatibility
* black and white lists for items to be kept on death
* black and white lists for items to be auto equipped after tombstone interaction

# 1.0.44
* fix for utility items from custom slot competing for extra utility slots

# 1.0.43
* minor fixes

# 1.0.42
* fixed occasional error on loading

# 1.0.41
* fixed invisible element prevented drag'n'droping item out of inventory

# 1.0.40
* fixed binding of gamepad buttons to slots hotkeys (apparently it worked with some controllers)

# 1.0.39
* Wrong format hotkeys will be clear automatically to prevent issues. Use a configuration manager to set up hotkeys.
* fixed rare issue with incorrect item in items collection

# 1.0.38
* new config in Mods compatibility to rebind F2 (open connect panel)

# 1.0.37
* final SimpleSort compatibility

# 1.0.36
* fixed items lose on death inside a dungeon
* further SimpleSort compatibility (post sorting weight calculations)

# 1.0.35
* SimpleSort compatibility (exclude extra slots from sorting)
* Recycle_N_Reclaim compatibility (ignore hotbar config ignores extra slots items)

# 1.0.34
* Call To Arms patch (trinket slot)
* BowsBeforeHoes arrow finding and counting compatibility
* Bombs and throwables now also go to ammo slot

# 1.0.33
* compatibility with ZenBeehive
* minor optimization

# 1.0.32
* Quick Stack Store Sort Trash Restock mod compatibility for restock of quick, misc, food and ammo slots
* fix for error on mod initialization when language has not been set explicitly
* thunderstore version now has YamlDotNet as dependency

# 1.0.31
* another attempt at better ValheimPlus inventory rows count compatibility
* fixed hotbars cycling when alternative placing is up

# 1.0.30
* fixed duping things after death

# 1.0.29
* players without mod installed should now see extra items in Tombstone on interaction
* Czech translation added
* custom item lists for food and ammo slot items (you can now add bombs to ammo slots)

# 1.0.28
* custom item list for misc slot items (by default includes items required to summon bosses)
* vanilla slot order and Unique utility items configs now use custom config drawers to easier format handling

# 1.0.27
* Polish translation refined
* ServerSync updated
* more compat for mods altering original hotkey bar

# 1.0.26
* patch 0.220.3
* minor performance improvements

# 1.0.25
* Ukrainian translation
* fix for rare error related to equipment effects

# 1.0.24
* hotbars now has configurable anchor to make it work the same on clients with different resolutions and GUI scales (if you moved panels you may need to reposition it again)
* new config options to change weight of items in corresponding slots

# 1.0.23
* new config option to prevent auto pickup items to extra slots

# 1.0.22
* more compatibility for Valheim+ inventory

# 1.0.21
* fixed Backpacks and BBH's Quiver pushing some items to quick slots on player load

# 1.0.20
* new configs for slot groups to prevent "Stack All" from pulling items from configured slot types
* new config to prevent "Stack All" from pulling items from hotbar
* rare issue: some outdated custom meads now will properly go into Food slots
* default hotkeys for Food slots now: Alt + Q, Alt + E, Alt + R

# 1.0.19
* more intuitive handling for similar hotkeys use in quick bars

# 1.0.18
* new config option for stack size Color of slots in equipment panel
* quick slots hotbars will no longer overlap map window

# 1.0.17
* new config option to use several hotbar items at once
* changed the logic of checking quick slots and utility slots activity. If only one of the values ​​(global key or discovered item) is specified - checking for the unfilled one will not be performed
* keyboard shortcuts will be ordered in similar manner to prevent potential issues with button order and to be more homogenous for similar hotkeys usage

# 1.0.16
* ValheimPlus multiplayer compatibility
* tooltip names format for hotkey slots made configurable

# 1.0.15
* AzuAutoStore compatibility to ignore items in extra slots
* Quick Stack Store Sort Trash Restock compatibility to ignore items in extra slots

# 1.0.14
* ok fine there is food slots hotbar now
* and you can place potions in food slots
* hotbar gamepad selection will now properly cycle through hotbars in order (top -> bottom, left -> right) if hotbars were repositioned
* PlantEasily gamepad double selection fixed
* MagicPlugin custom slot compatibility

# 1.0.13
* ammo and quickslots hotbar made more configurable
* options to keep items in slots after death (compatible with Death Tweaks)

# 1.0.12
* fix for error on new character creation

# 1.0.11
* Chinese translations refined
* BetterProgression compatibility
* Valheim Enchantment System compatibility
* Inventory rows amount can now be changed ingame without issues
* Inventory rows obtaining progression
* Fix for spamming error on tooltip

# 1.0.10
* german translation refined
* new option to hide stack size in hot bars

# 1.0.9
* EpicLoot enchantments will work at any custom slot
* EpicLoot support for ignoring sacrifice of hotbar items (quickslots and misc slots could be excluded as well)

# 1.0.8
* new API methods
* translations fixed
* mod name in translation section fixed (it lacked space)
* Backpacks compatibility
* Extra Slots Custom Slots mod support

# 1.0.7
* fixed an issue where you could not drag unequipped item in slot

# 1.0.6
* incompatibility with RequipMe
* option to auto equip last equipped weapon/shield on tombstone interaction
* better check if tombstone easy fits into inventory

# 1.0.5
* even better ValheimPlus compat
* fix for tombstone extra utility items preventing tombstone spawn

# 1.0.4
* more built-in translations
* hotbars refinements
* prevent simultaneous hotbar item use with similar hotkeys
* quick and extra utility slots progression requires previous slots to be obtained
* PlantEasily gamepad compatibility
* dragging item visuals and logic refinements

# 1.0.3
* configurable autoequip on tombstone interaction
* fixed major issue with BetterArchery compatibility on tombstone interaction
* hotbars made more responsive and stable
* hotbars visibility can now be toggled ingame
* perfomance improvements
* +2 more extra utility slots (up to 5 total utility items)
* +3 more extra rows (up to 5 extra rows and total 9 rows of player inventory)

# 1.0.2
* compatibility with EpicLoot enchantments for extra utility slot items

# 1.0.1
* unique-equipped utility items configurable
* valheim plus better compatibility yet it's recommended to disable inventory section

# 1.0.0
 * Initial Release