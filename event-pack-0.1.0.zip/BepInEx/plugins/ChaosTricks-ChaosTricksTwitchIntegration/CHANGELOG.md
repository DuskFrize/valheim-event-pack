### Update 2.2.3

- Fixed compatibility with Valheim release v1.0

### Update 2.2.2

- Fixed deleting spawned enemies when entities out of the player range

### Update 2.2.1

- Fixed processing a case where spawned enemy network class is null

### Update 2.2.0

- Fixed in-game chat notifications for patch 0.218.15
- Updated ChaosTricks libs

### Update 2.1.1

- Fixed buffs and immortality for patch 0.217.14

### Update 2.1.0

- Fixed compatibility with Valheim June patch 0.216.9

### Update 2.0.0

- Added new events
- Fixed weather and custom buff events activating for not host players
- Fixed names of spawns for not host players
- Other fixes and improvements

### Update 1.1.0

- Added new events for the Mistlands update
