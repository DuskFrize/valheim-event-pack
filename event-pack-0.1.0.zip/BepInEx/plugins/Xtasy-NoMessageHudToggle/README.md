# No Message HUD Toggle

A client-side Valheim mod that lets you hide unwanted Message HUD notifications.

## Features

- Persistent enable/disable setting.
- **F8** temporarily toggles the mod at runtime.
- F8 does **not** change the saved configuration.
- Pickup notifications, including creature drops, can be hidden.
- Inventory change notifications can be hidden.
- Skill-up messages can be hidden.
- New item/trophy and other `$msg_new*` notifications can be hidden.
- New materials, recipes, stations and station-level-up notifications have separate filters.
- Event/raid notifications (`$event_*`) have a separate filter.
- Regular center-screen messages have a separate filter.
- Uncategorized Message HUD notifications can be hidden with `Hide Other`.

## Installation

Install through Thunderstore Mod Manager, r2modman or another compatible mod manager.

The mod is **client-side**. It does not need to be installed on a dedicated server.

BepInEx is installed automatically as a dependency.

## Configuration

After the first launch, edit:

`BepInEx/config/com.xtasy.NoMessageHudToggle.cfg`

Default configuration:

```ini
[General]
Enabled = true
Toggle Hotkey = F8

[Messages]
Hide Item Pickup = true
Hide Inventory Notifications = true
Hide Skill Up = true
Hide New Items = true
Hide New Materials = true
Hide New Recipes = true
Hide New Stations = true
Hide Station Level Up = true
Hide Events = false
Hide Center Messages = true
Hide Other = false
```

### Runtime toggle

Press **F8** to temporarily turn the filtering on or off.

The saved `Enabled` value is not changed by F8. On the next game launch, the mod starts according to the saved configuration.

## Compatibility

Tested with:

- Valheim 1.0.15
- BepInExPack Valheim 5.4.2350/5.4.2351

The mod patches:

- `MessageHud.ShowMessage`
- `MessageHud.QueueUnlockMsg`

If a future Valheim update changes these methods or their signatures, the mod may require an update.

## Known behavior

Creature drops use the same `$msg_added` Message HUD mechanism as normal item pickups, so they are controlled by **Hide Item Pickup**.

Raid/event messages are checked before center-screen messages because Valheim can display events using `MessageHud.MessageType.Center`. Therefore **Hide Center Messages** does not hide `$event_*`; use **Hide Events** for raids/events.

## License

MIT
