# Changelog

## 1.0.0

- Added separate filtering for event/raid notifications.
- Added center-screen message filtering without suppressing event messages.
- Added generic `$msg_new*` handling for new items and trophies.
- Added separate filters for new materials, recipes, stations and station-level-up messages.
- Added inventory notification filtering.
- F8 runtime toggle does not modify persistent configuration.
- Initial runtime state follows the saved `Enabled` setting.

## 1.1.0

- Fixed hotkey triggering while typing in chat, console, portal names, signs, and other text input fields.

## 1.2.0

- Added automatic config reload.
- Config changes now apply without restarting the game.