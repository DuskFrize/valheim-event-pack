# Conditional Config Sync

> **[*Conditional* Conditional Config Sync](https://github.com/shudnal/ConditionalConfigSync/blob/master/docs/conditional-conditional-config-sync.md)** — embed the optional CCS adapter directly into your mod project (as a source file or via ILRepack) and automatically add config synchronization when **CCS 1.0.10 or newer** is installed in the current modpack; without CCS, or with CCS 1.0.5-1.0.9, the same settings remain ordinary local BepInEx config entries.

Conditional Config Sync is a shared infrastructure library for Valheim mods. It does not add gameplay content, items, UI, or configuration options of its own. Install it when another mod lists it as a dependency.

The package provides centralized config synchronization, version checks, server-side ownership and admission policy overrides, protected locking, and synchronized runtime values. Keeping this logic in one standalone dependency means fixes can be shipped by updating this package instead of rebuilding every mod that uses it.

It is an independent synchronization option for mod authors who need per-setting ownership policy, hidden-setting controls, and expanded runtime-value behavior. Jotunn and ServerSync remain separate libraries with their own use cases and development paths.

## For players

Normally, a mod manager installs Conditional Config Sync automatically as a dependency. Keep it installed while any enabled mod depends on it.

This package:

- does **not** replace, modify, or intercept `ServerSync` used by other mods;
- does **not** migrate or modify configuration belonging to other mods;
- can run alongside Jotunn and mods that use `ServerSync`;
- only handles mods that were explicitly built against Conditional Config Sync.

Installing this package alone has no gameplay effect.

## Package contents

The Thunderstore package contains:

- `ConditionalConfigSync.Plugin.dll` - the BepInEx bootstrap registered as `_shudnal.ConditionalConfigSync`;
- `ConditionalConfigSync.dll` - the public API and synchronization runtime used by dependent mods;
- `ConditionalConfigSync.xml` - IntelliSense documentation for IDEs and mod authors;

Both DLL files must remain installed together. The XML and documentation files are optional at runtime but useful for development, verification, and redistribution.

## Compatibility

Conditional Config Sync uses its own BepInEx and Harmony identifier:

```text
_shudnal.ConditionalConfigSync
```

It does not patch, replace, or disable Jotunn synchronization or `ServerSync`. These libraries can coexist in the same process because each mod continues using the synchronization library it was compiled against.

Embedding or ILRepacking `ConditionalConfigSync.dll` into another mod is intentionally unsupported. An embedded copy rejects initialization and reports an explicit error. Use the standalone Thunderstore dependency instead.

## For server administrators

### Default behavior

Every registered setting has one of three ownership modes selected by its mod author:

- `AlwaysServerControlled` - always synchronized from the server and cannot be released by policy. Mod authors should use it for shared mechanics and synchronized state that must use the same effective value on the server and every client. Typical examples are gameplay rules, world-state generation, shared events, network-visible calculations, and feature switches that would malfunction when peers disagree;
- `Conditional` - uses the mod-defined server/client default and may be overridden by server policy. It is appropriate when an administrator may reasonably choose between one shared server value and per-client behavior;
- `AlwaysClientControlled` - always local to each client and cannot be forced by sync policy. It is intended for presentation, local UI, controls, and other behavior that does not participate in shared mechanics.

A mod may also register one locking setting that controls whether ordinary clients may publish changes to server-controlled settings. Hidden-state policy is independent and may hide settings from compatible configuration managers in any ownership mode. A mod author may additionally opt its remote-installation requirement into `ModRequirementMode.Conditional`, allowing the server to require or permit clients without that specific mod while retaining the author's declared default.

Policy files are created in `BepInEx/config/shudnal.ConditionalConfigSync` on the server. Existing files are read synchronously during server startup before the file watchers are used. Reads are retried until the file metadata is stable, so common editor save patterns such as truncate/write/rename do not replace a working policy with a partial snapshot. The files are then watched for changes and can be edited while the server is running.

### Locking behavior

Conditional Config Sync provides a locking model familiar to ServerSync users and adds explicit protection for the locking setting itself.

When the lock is enabled:

- ordinary clients cannot publish changes to server-controlled settings;
- server administrators receive an exemption and may edit them;
- client-controlled settings remain local and editable.

When the lock is disabled, ordinary clients may publish changes to server-controlled settings only if the mod author explicitly enabled unlocked-client updates. This option is disabled by default; administrators remain authorized regardless of the option.

The locking setting is always protected:

- it is always server-controlled;
- it cannot be forced to client-controlled through policy;
- a non-admin client cannot change it even while the rest of the configuration is unlocked.

This prevents a client from attempting to grant itself permission by changing the lock setting first.

Client-side read-only metadata is only a user-interface aid. CCS also guards registered BepInEx values at runtime and independently validates every client update on the server. Accepted client values are applied and normalized by the server, then redistributed in a new server-built package. The original client package is never forwarded to other clients. Rejected updates receive an authoritative correction when the sender is still connected.

### Sync policy

File:

```text
BepInEx/config/shudnal.ConditionalConfigSync/ConditionalConfigSync.SyncPolicy.cfg
```

A rule may target one exact setting or an entire config section:

```text
ModGuid.Section.Key
ModGuid.Section
```

Use `+` to force server ownership and `-` to force client ownership:

```ini
# Exact setting
+ author.mod.General.Damage multiplier
- author.mod.Interface.Show status panel

# Every Conditional setting in a section
+ author.mod.Gameplay
- author.mod.Interface
```

Rules:

- `+ identifier` forces matching `Conditional` settings to be server-controlled;
- `- identifier` forces matching `Conditional` settings to be client-controlled;
- an exact setting rule takes precedence over a whole-section rule;
- no matching entry preserves the mod author's default;
- `AlwaysServerControlled` and `AlwaysClientControlled` ignore sync-policy ownership overrides;
- malformed, duplicate, conflicting, unknown, and ignored entries can be reported by `conditionalconfigsync_policy_validate`;
- forcing the protected locking setting to client-controlled is ignored.

Policy is normally edited through these files. Compatible configuration UIs may use the public API to let an authenticated server administrator switch an individual `Conditional` setting between server-controlled and client-controlled ownership. The server persists that action as an exact-setting rule, or removes the exact rule when the requested ownership is already provided by the mod default or a section rule. Console commands intentionally provide reload, validation, status, and dump operations but do not add, remove, or rewrite rules.

Typical uses:

- enforce an otherwise client-local gameplay option on a public server;
- release a cosmetic or UI setting from server control;
- switch a complete section without listing every setting;
- override one setting differently from the rest of its section;
- temporarily test a different ownership model without rebuilding the mod.

### Mod requirement policy

File:

```text
BepInEx/config/shudnal.ConditionalConfigSync/ConditionalConfigSync.ModRequirements.cfg
```

This policy controls connection admission for mods whose authors explicitly use `ModRequirementMode.Conditional`. It is separate from config ownership and is not a general client mod-list allow/deny mechanism.

Use `+` to require the mod on connecting clients and `-` to allow clients without it:

```ini
# Require this mod even if the author default is optional
+ author.mod

# Permit clients without this mod even if the author default is required
- another.author.mod
```

Rules:

- no matching rule preserves the mod author's `ModRequired` default;
- `+ ModGuid` forces the consumer to be required for new incoming client connections;
- `- ModGuid` permits new incoming clients that do not provide that consumer;
- rules are ignored for `ModRequirementMode.Fixed`, which is the backward-compatible default;
- the policy is server-side only and does not weaken a modded client's own requirement that the server provide the mod;
- a missing consumer is allowed when the effective server requirement is optional, but an advertised Conditional consumer must still pass its normal version and CCS protocol compatibility checks;
- Conditional clients advertise their consumer handshake even when the author default is optional, so a server can reliably force that consumer to be required;
- requirement policy is snapshotted when a connection attempt begins. Reloading the file affects later connection attempts and never disconnects already connected peers.

This supports deliberate degraded-operation scenarios such as crossplay servers: an author can recommend and default to `ModRequired = true`, while explicitly allowing a server administrator to accept clients that cannot install the mod.

### Hidden settings

File:

```text
BepInEx/config/shudnal.ConditionalConfigSync/ConditionalConfigSync.HiddenConfigs.cfg
```

Add a mod GUID, whole-section identifier, or exact setting identifier per line:

```ini
# Every setting registered by a mod
author.mod

# Every setting in a section
author.mod.Advanced

# Exact settings
author.mod.Advanced.Internal multiplier
author.mod.Debug.Enable verbose output
```

A mod, section, or exact-setting match marks the affected settings as not browsable in compatible configuration managers. Whole-mod identifiers are supported only by `HiddenConfigs.cfg`; `SyncPolicy.cfg` still requires a section or exact-setting target. Hiding is a presentation policy, not a security boundary: the setting still exists, and its synchronization behavior is controlled separately by `SyncPolicy.cfg`, its `ConfigSyncMode`, and the lock state.

Typical uses:

- hide advanced or dangerous options from ordinary configuration UI;
- simplify a public server's visible settings;
- hide every setting of a mod or a whole internal section with one line;
- keep diagnostic options available in the config file without advertising them in the manager.

### Debug logging

Local debug settings are stored in:

```text
BepInEx/config/shudnal.ConditionalConfigSync/ConditionalConfigSync.Debug.cfg
```

Console commands for diagnostics:

```text
conditionalconfigsync_debug
conditionalconfigsync_debug_server
```

Server policy commands:

```text
conditionalconfigsync_status
conditionalconfigsync_policy_reload
conditionalconfigsync_policy_validate
conditionalconfigsync_policy_dump
```

- `status` shows registered mods, config mode counts, effective config ownership, hidden settings, effective mod requirements, and policy-file paths;
- `policy_reload` reads and applies all policy files immediately on the Unity main thread;
- `policy_validate` reports syntax errors, duplicates, conflicts, unknown identifiers, and rules ignored by fixed modes;
- `policy_dump` writes `ConditionalConfigSync.PolicyDump.txt` with copy-ready mod, exact-setting, and section identifiers plus their author-defined modes/defaults.

Debug logging supports `Basic`, `Verbose`, and `Trace` levels and an optional mod-name filter. Normal startup stays quiet; warnings and errors remain visible without debug logging.

For synchronization performance analysis, `Verbose` logs package serialization time, compression time, raw and wire sizes, compression ratio, and whether a complete server snapshot was built or reused. `Trace` additionally logs the serialized payload size of every config value and custom value. This is intended for short profiling sessions with a mod-name filter when large custom data such as generated definitions, images, or other blobs is synchronized.

A `CustomSyncedValue<string>` whose serialized payload reaches 128 KiB produces one warning per synchronization instance per network session even when debug logging is disabled. The warning does not reject or alter the value; it highlights cases where sending already parsed structured or binary runtime data may avoid repeated large-string allocation and client-side text parsing.

### Connection rejection diagnostics

Version-check disconnects are always written as errors, independently of the debug logging configuration. Server logs distinguish these cases:

- no matching version handshake was received before `PeerInfo`;
- a legacy or incomplete handshake omitted the CCS protocol field;
- the reported CCS protocol differs from the required protocol;
- the remote mod version or minimum version is malformed;
- the remote mod is older than the local minimum, or the remote minimum is newer than the local mod.

Successful receive logs include the remote peer identifier. New CCS releases also append their package version to the existing protocol 1 handshake as optional diagnostic metadata; older protocol 1 peers remain compatible and are shown as `not reported`.

Before the server sends Valheim's version error, CCS sends one bounded structured disconnect report containing a report ID and one or more reason codes. The same report ID is written to the server and client logs for correlation. A current client associates the report with the active connection attempt, preserves it across the failed `ZNet` shutdown long enough for the main menu to display it, and discards stale reports after a new connection, a successful admission, display, or a short timeout.

CCS does not create or own a separate error window. It appends its English explanation only when the current connection has an explicit pending CCS report; a generic `ErrorVersion` from another compatibility provider is not treated as a CCS failure. The report is appended to the existing Valheim connection-error text before Jotunn and ServerSync process the same form:

- Jotunn keeps its own compatibility window and receives the already enriched failed-connection text;
- ServerSync may append its own diagnostics to the same vanilla text;
- when Jotunn does not replace the vanilla panel, CCS performs an idempotent one-frame layout normalization after the other postfixes finish.

Older clients that do not register the disconnect-report RPC still receive the normal Valheim version error and must use the server log for the detailed cause. If CCS is entirely absent or fails before registering its RPC on the rejected client, no CCS implementation exists there to display the server-provided reason.

## For mod authors

Conditional Config Sync is a third-party standalone dependency. Do not embed it with ILRepack and do not ship private copies inside individual mods.

Reference only:

```text
ConditionalConfigSync.dll
```

For direct compile-time API use, declare the standalone BepInEx plugin as a hard dependency:

```csharp
[BepInDependency(
    "_shudnal.ConditionalConfigSync",
    BepInDependency.DependencyFlags.HardDependency)]
```

Use the namespace:

```csharp
using ConditionalConfigSync;
```

The public API keeps familiar `ConfigSync` names also used by ServerSync:

```csharp
internal static readonly ConfigSync configSync = new ConfigSync(pluginID)
{
    DisplayName = pluginName,
    CurrentVersion = pluginVersion,
    MinimumRequiredVersion = minimumCompatibleVersion,
    ModRequired = true
};
```

### Optional soft dependency integration

Mods that remain fully functional without synchronized configuration may use the official source/ILRepack adapter instead of referencing `ConditionalConfigSync.dll`.

The adapter is maintained in:

```text
ConditionalConfigSync.API/ConditionalConfigSyncAPI.cs
```

You can either copy that source file directly into the mod project or reference `ConditionalConfigSync.API.dll` during development and ILRepack/internalize it into the final mod DLL. Do not distribute `ConditionalConfigSync.API.dll` as a separate runtime dependency.

Declare CCS as a soft BepInEx dependency so it is ordered before the consumer when installed while the consumer still loads without CCS:

```csharp
// Optional synchronization requires CCS 1.0.10 or newer.
[BepInDependency(
    ConditionalConfigSyncAPI.ConfigSync.PluginGuid,
    BepInDependency.DependencyFlags.SoftDependency)]
```

The minimum CCS version for this optional integration is **1.0.10**. BepInEx 5 cannot encode a minimum version and keep the dependency soft: its versioned `BepInDependency` constructor is always a hard dependency. The embedded adapter therefore checks `ConditionalConfigSyncAPI.ConfigSync.MinimumCcsVersion` at runtime.

The adapter always returns ordinary BepInEx `ConfigEntry<T>` objects:

- CCS absent: local BepInEx configuration only;
- CCS 1.0.5-1.0.9: local BepInEx configuration only; the optional bridge is intentionally not activated;
- CCS 1.0.10 or newer: the same entries are registered with CCS through the official reflection bridge.

```csharp
var optionalSync = new ConditionalConfigSyncAPI.ConfigSync(
    pluginID,
    pluginName,
    pluginVersion,
    minimumRequiredVersion: minimumCompatibleVersion,
    modRequired: false,
    logger: Logger);

ConfigEntry<bool> useDurability = optionalSync.Bind(
    Config,
    "Gameplay",
    "Use durability",
    true,
    "Enable durability.",
    ConditionalConfigSyncAPI.SyncMode.AlwaysServerControlled);

ConfigEntry<KeyboardShortcut> snappingKey = optionalSync.Bind(
    Config,
    "Controls",
    "Snapping key",
    new KeyboardShortcut(KeyCode.LeftShift),
    "Local snapping key.",
    ConditionalConfigSyncAPI.SyncMode.AlwaysClientControlled);
```

The helper resolves the bridge through the active BepInEx plugin instance for `_shudnal.ConditionalConfigSync`; it does not scan `AppDomain` assemblies by name. Passive copies loaded by metadata scanners therefore cannot be selected accidentally.

This mode is appropriate only when local unsynchronized fallback is a valid operating mode. If the mod requires synchronized settings for correct gameplay or network behavior, use the normal hard dependency instead.

### Requiring the mod on the remote side

`ModRequired` is the mod author's default compatibility contract for whether the **owning mod** must also be installed on the remote peer. This is separate from the BepInEx hard dependency on Conditional Config Sync itself:

- the hard dependency requires CCS on the same machine where the owning mod is installed;
- `ModRequired = true` means a client running the mod requires the server to provide a compatible copy, and a server requires connecting clients to provide one;
- `ModRequired = false` allows the remote side to omit the owning mod.

The default `ModRequirementMode.Fixed` preserves this behavior exactly and cannot be overridden by server policy:

```csharp
internal static readonly ConfigSync configSync = new ConfigSync(pluginID)
{
    DisplayName = pluginName,
    CurrentVersion = pluginVersion,
    MinimumRequiredVersion = minimumCompatibleVersion,
    ModRequired = true
};
```

Use `ModRequirementMode.Conditional` only when the author explicitly accepts that a server administrator may strengthen or relax the requirement for **incoming clients**:

```csharp
internal static readonly ConfigSync configSync = new ConfigSync(pluginID)
{
    DisplayName = pluginName,
    CurrentVersion = pluginVersion,
    MinimumRequiredVersion = minimumCompatibleVersion,
    ModRequired = true,
    ModRequirementMode = ModRequirementMode.Conditional
};
```

In this example, the author's recommendation remains `Required`. A server running the mod may place `- pluginID` in `ConditionalConfigSync.ModRequirements.cfg` to accept unmodded or console clients. This server-side override is intentionally asymmetric: a client running the mod still uses the author's `ModRequired = true` default and refuses to join a server where the mod itself is absent.

A Conditional consumer with `ModRequired = false` also advertises its version handshake from the client. That allows a server policy to use `+ pluginID` and require the mod even though the author's default is optional. Fixed optional consumers retain the original one-sided handshake behavior.

When a Conditional consumer is optional for a particular incoming connection, complete absence is accepted. If the client does advertise that consumer, its normal mod-version and CCS protocol compatibility checks still apply. Relaxing a required-by-default consumer to optional therefore does not relax its compatibility range for clients that still have the mod. Conversely, if an optional-by-default consumer is forced to required and no explicit `MinimumRequiredVersion` was supplied, the server uses the existing required-consumer fallback of `CurrentVersion` for that admission. The server snapshots the effective requirement when the connection begins, so a live policy reload changes later connection attempts only and does not disconnect existing players.

When a client-side optional instance receives no matching server handshake and the connection completes successfully, CCS returns that instance to local source-of-truth ownership. Its local values remain editable and are not published to the server. This is not an initial server synchronization, so `InitialSyncDone` remains false and `InitialSyncCompleted` is not raised.

`MinimumRequiredVersion` is the oldest compatible owning-mod version, not automatically the current release. If compatible releases span several versions, keep this value at the oldest supported version instead of advancing it with every package release.

When the remote copy exists, `CurrentVersion`, `MinimumRequiredVersion`, and the CCS wire protocol are used for compatibility checks. Late registration or `RequestFullSync()` does not repeat connection admission, so configure both `ModRequired` and `ModRequirementMode` while creating the `ConfigSync` instance.

### Querying a remote consumer

CCS 1.0.9 exposes a stable capability query for optional peer-to-peer features that should only target peers running a compatible copy of a consumer mod:

```csharp
RemoteConsumerState state = ConditionalConfigSync.GetRemoteConsumerState(pluginID, peerUid);
bool supported = ConditionalConfigSync.HasCompatibleConsumer(pluginID, peerUid);
```

`peerUid` is the Valheim routed peer UID (`ZNetPeer.m_uid`), which is also the sender/target identifier used by `ZRoutedRpc`. The returned state is:

- `Unknown` - CCS cannot currently determine the capability, for example before peer admission, after disconnect, when a server-side query has no local consumer/version check to compare against, when an unregistered consumer is silent on another client, or when an older server does not publish cross-client capability state;
- `Missing` - admission completed and the peer did not advertise a consumer whose installed copies are expected to advertise during the CCS version handshake;
- `Incompatible` - the peer advertised the consumer but its normal CCS version/protocol compatibility check did not pass for this relationship;
- `Compatible` - the consumer was advertised and passed the applicable CCS version/protocol compatibility check.

The server answers its own queries directly from the existing `VersionCheck` handshake state. For client-to-client queries, the server derives a compact per-recipient snapshot after `PeerInfo` and sends only `peer UID + consumer GUID + state`; raw consumer versions, config data, and handshake payloads are not exposed. A client receives entries only for consumer GUIDs that it advertised itself, so this API is a compatibility query for locally participating consumers rather than a remote mod-list enumeration mechanism. This is capability propagation, not a second consumer handshake, and CCS does not transport application payloads for the consumer mod.

For client-to-client discovery, the server reuses every parsed CCS consumer handshake it receives. If both peers advertise the same consumer GUID, their advertised version ranges and CCS protocol are compared directly, so this also works when that consumer is not installed on the server. When the server does have the consumer registered, its ordinary validation result is enforced as an additional requirement and a missing handshake can be reported as `Missing` when that consumer is known to advertise whenever installed. Without a matching server-side consumer, a silent target remains `Unknown` rather than being guessed as absent; `HasCompatibleConsumer` is false for both `Unknown` and `Missing`. Fixed optional consumers intentionally do not advertise from clients and therefore cannot provide cross-client capability discovery through this API. Capability state is refreshed when peers join or leave and is cleared on shutdown/reconnect.

A mod that calls these APIs must declare Conditional Config Sync 1.0.9 or newer as its minimum dependency. Older CCS peers remain protocol-compatible; they simply do not provide cross-client capability snapshots.

Register an existing BepInEx entry with its mode in one call:

```csharp
ConfigEntry<float> damage = Config.Bind(
    "Gameplay",
    "Damage multiplier",
    1f,
    "Server gameplay setting");

configSync.AddConfigEntry(
    damage,
    ConfigSyncMode.AlwaysServerControlled);
```

Use `AlwaysServerControlled` whenever the setting controls a common mechanic whose result must remain consistent across the server and all clients. Do not leave such a setting `Conditional` merely to make it configurable through policy: allowing one client to restore a local value can make shared calculations, events, state transitions, or network-visible behavior diverge.

Or bind and register in one call:

```csharp
SyncedConfigEntry<bool> showPanel = configSync.AddConfigEntry(
    Config,
    "Interface",
    "Show status panel",
    true,
    new ConfigDescription("Local UI setting"),
    ConfigSyncMode.AlwaysClientControlled);
```

For policy-controlled settings, specify the default ownership without assigning a second property after registration:

```csharp
SyncedConfigEntry<float> scale = configSync.AddConfigEntry(
    Config,
    "Gameplay",
    "World scale",
    1f,
    new ConfigDescription("May be reassigned through SyncPolicy"),
    ConfigSyncMode.Conditional,
    serverControlledByDefault: true);
```

Compatibility overloads remain available:

```csharp
configSync.AddConfigEntry(entry);        // Conditional, server-controlled by default
configSync.AddConfigEntry(entry, false); // Conditional, client-controlled by default
```

Passing the mode/default directly prevents a temporary server-controlled registration state and avoids duplicate policy-state transitions during initialization.

Runtime values are also available:

```csharp
public static readonly CustomSyncedValue<string> mapData =
    new(configSync, "Map data", "");
```

Use `CustomSyncedValue<T>` for state. Equal assignments are suppressed by its comparer. Use `SequencedCustomSyncedValue<T>` for event-like data where repeated equal payloads must still be delivered in order.

The XML file shipped beside the DLL documents the public API, assignment modes, comparers, priorities, version checks, and integration details directly in IDE IntelliSense.

### Effective configuration state

Every registered config wrapper exposes read-only metadata for configuration UIs and diagnostics:

- `ServerControlledByDefault` returns the normalized ownership selected by the mod;
- `IsServerControlled` returns the current effective ownership, or the normalized mod default before policy state is initialized;
- `IsPolicyStateInitialized` reports whether policy state is available for the current server session;
- `IsSynchronizationOverridden` reports only policy changes that alter the mod-defined ownership;
- `EffectiveOverride` identifies `ForceServerControlled` or `ForceClientControlled`;
- `IsHidden` reports the effective hidden state;
- `SynchronizationPolicyControlState` distinguishes an available policy control operation from a missing compatible server session, missing administrator access, or a fixed ownership mode;
- `CanChangeSynchronizationPolicy` is a convenience boolean that is true only when `SynchronizationPolicyControlState` is `Available`;
- `ToggleSynchronizationPolicy()` requests the opposite effective ownership and persists the resulting exact-setting rule on the server.

A policy rule that matches the mod default is intentionally reported as `ConfigSyncOverride.None`, because it does not change runtime behavior. These properties are local read-only views of state already carried by the existing protocol and do not add a new network format.

### Protocol compatibility

Conditional Config Sync uses a numeric wire protocol version that is independent from the DLL and package version.

The first public release uses protocol `1`. Clients and servers must use the same protocol version. The protocol number is increased only when an incompatible network-format change is introduced; ordinary library updates do not require a protocol bump while the wire contract remains compatible.

Conditional mod requirements reuse the existing version-handshake packet and do not add a new wire field. Existing consumers compiled against CCS 1.0.5 remain `ModRequirementMode.Fixed` by default and can run against the newer core DLL without being rebuilt. Only consumers that use the new `ModRequirementMode.Conditional` API need to declare the newer CCS package as their minimum dependency.

Policy-control support is advertised through an optional trailing capability field in the existing lock-exemption entry. Older clients ignore the extra payload, while newer clients keep interactive policy controls disabled when connected to a server that does not advertise the feature.

### Late registration and resynchronization

Configs and custom values registered after the network session starts are handled automatically:

- the server batches newly registered values and broadcasts their current state;
- a client that registers values after `InitialSyncCompleted` requests a complete resync from the server;
- multiple registrations in the same frame are coalesced into one operation.

A `ConfigSync` instance created after the normal connection startup window also registers its RPC handlers and requests its first complete package automatically. A mod that rebuilds a dynamic registration set can call `configSync.RequestFullSync()` explicitly. The method returns `false` when no remote server is connected.

Connection admission and mod-version validation still happen during Valheim's normal peer handshake. Mods that require version enforcement should create their `ConfigSync` instance before connecting; late resync updates data but does not retroactively repeat the completed connection check.

### Lifecycle and diagnostic events

Each `ConfigSync` instance exposes optional events for mods that need to rebuild derived runtime state or provide their own diagnostics:

- `InitialSyncCompleted` after the first complete server package has been applied on a client;
- `ServerConnectionReset` after server values are cleared and local fallback values are restored;
- `PolicyStateChanged`, `ServerControlledChanged`, and `HiddenStateChanged` when effective policy changes;
- `LockStateChanged` when the effective lock or administrator exemption changes;
- `SyncRejected` when a package or outgoing update is rejected for permissions, malformed data, queue overflow, or the 20 MiB safety limit.

Subscriber exceptions are isolated and logged, so one consumer cannot interrupt synchronization for the remaining mods or entries. Full usage notes are included in the XML documentation.

### Why a standalone dependency

Compared with embedding a sync source file or ILRepacking a private DLL:

- all dependent mods use one maintained implementation;
- fixes to networking, policy, serialization, authorization, or configuration-manager integration require updating only this package;
- duplicate Harmony patches, watchers, commands, and static registries are avoided;
- server administrators get one common policy layer for all participating mods;
- dependent mod packages remain smaller and simpler;
- compatible 1.x releases keep the core assembly identity stable so already compiled dependent mods do not require rebuilding merely to receive runtime fixes.

For Thunderstore, add this package to the mod's dependencies. Do not copy either Conditional Config Sync DLL into the dependent mod's own package.

## Functional differences from ServerSync

### Distribution and isolation

- Delivered as a standalone BepInEx hard dependency instead of being embedded with ILRepack.
- Uses a dedicated namespace, BepInEx GUID, Harmony ID, RPC names, and package format.
- Does not modify or intercept ServerSync instances used by other mods.
- Detects and rejects unsupported embedded Conditional Config Sync copies.

### Config ownership and policy

- Retains separate local and active server values on clients.
- Supports runtime switching between server-controlled and client-controlled state.
- Adds three explicit config modes: `AlwaysServerControlled`, `Conditional`, and `AlwaysClientControlled`.
- Adds server-side `SyncPolicy.cfg` overrides for exact settings and complete sections.
- Adds opt-in `ModRequirementMode.Conditional` admission policy through `ModRequirements.cfg`, preserving fixed `ModRequired` behavior for existing consumers.
- Allows compatible configuration UIs to request administrator-authorized exact-setting policy toggles while keeping the policy file as the persistent source of truth.
- Adds whole-mod, section-level, and exact-setting `HiddenConfigs.cfg` rules for Configuration Manager visibility.
- Sends effective config state together with server values.

### Locking and administration

- Keeps the lock and administrator exemption model familiar from ServerSync.
- Protects the locking setting itself even while the configuration is unlocked.
- Rejects non-admin network attempts to change the protected lock.
- Treats unlocked non-admin publication as an explicit mod opt-in and disables it by default.
- Re-evaluates write permission independently on the client runtime and on the server.
- Uses the connected peer identity for current Valheim admin checks and clearer logs.
- Validates an entire client update before applying values and redistributes only server-canonical state.

### Custom synchronized values

- Distinguishes state-like `CustomSyncedValue<T>` from event-like `SequencedCustomSyncedValue<T>`.
- Supports explicit `AssignLocalValue`, `AssignLocalValueIfChanged`, and `AssignLocalValueAndNotify` behavior.
- Supports custom equality comparers for collections and domain types.
- Supports priorities and preserves ordering for sequenced values.
- Mods that mutate a custom value object, collection, array, or other reference in place must call `NotifyChanged()` after the mutation. This was already required to publish the change and now also invalidates the reusable full-sync snapshot.
- Defers outgoing updates safely instead of dropping changes during active synchronization.

### Serialization and networking

- Regular `ConfigEntry` values use BepInEx TOML conversion based on the local setting type.
- Custom values retain typed Valheim package serialization and support `ISerializableParameter`.
- Uses length-prefixed entries so unknown server entries can be isolated and client updates can be validated strictly.
- Keeps legacy client `ConfigState` claims wire-compatible only when they match server policy, while never trusting or forwarding them.
- Builds a new canonical server package after accepted client updates and includes the initiating client in the result.
- Adds compression, fragmentation, queue limits, payload limits, and clearer failure logging.
- Caches complete server synchronization snapshots by authoritative state revision and administrator class, including already compressed wire data, so later clients do not repeatedly serialize and compress unchanged state.
- Invalidates those snapshots when synchronized config/custom values, effective policy state, accepted client updates, or registrations change; complete resyncs and full authoritative corrections use the same cache.
- Adds optional package timing/size diagnostics without changing serialization bytes when diagnostics are disabled.
- Adds an independent numeric protocol version with exact client/server matching.
- Supports automatic late registration and explicit complete resynchronization.

### Diagnostics and documentation

- Adds stable/retried policy reads so partial editor writes do not replace the active policy.
- Cleans up policy watchers, network caches, pending queues, registered session handlers, and Harmony ownership when the relevant session or bootstrap ends.
- Adds per-mod receive logs with config/custom-value names for single-value updates.
- Includes optional filtered debug logging and server policy status/reload/validate/dump commands.
- Ships XML IntelliSense documentation and metadata descriptions for important public API members.
- Keeps architecture, compatibility rules, rejected alternatives, regression risks, and release requirements in `PROJECT_CONTEXT.md`.

## Migration note

Using Conditional Config Sync in a mod selects its synchronization implementation and protocol for that mod. Server and clients should update the dependent mod and this dependency together. Other installed mods that use ServerSync are unaffected.

## License and acknowledgements

Original Conditional Config Sync contributions are released under the [Unlicense](https://github.com/shudnal/ConditionalConfigSync/blob/main/LICENSE). The project uses the ServerSync approach and adapted code as a foundation; applicable ServerSync portions remain covered by its MIT-0 terms. Some implementation and compatibility ideas were informed by Jotunn. The retained notices are available in [THIRD_PARTY_NOTICES.md](https://github.com/shudnal/ConditionalConfigSync/blob/main/THIRD_PARTY_NOTICES.md).

## Security and privacy

Conditional Config Sync:

- contains no telemetry and sends no data to external services;
- makes no HTTP requests and opens no network connections outside the active Valheim client/server session;
- does not download, update, or execute external programs;
- does not access the Windows registry or ship native libraries;
- communicates only through Valheim RPC connections between the current server and its connected clients;
- treats client configuration packages as untrusted input, validates permissions on the server, and never forwards the original client package;
- writes only its policy, debug, dump, and diagnostic files under `BepInEx/config/shudnal.ConditionalConfigSync`;
- uses reflection only to access Valheim runtime members whose accessibility differs from publicized development assemblies;
- publishes unobfuscated binaries, XML API documentation, and source code.

## Links

- [Source repository](https://github.com/shudnal/ConditionalConfigSync)
- [Buy Me a Coffee](https://buymeacoffee.com/shudnal)
- [Discord](https://discord.gg/e3UtQB8GFK)
