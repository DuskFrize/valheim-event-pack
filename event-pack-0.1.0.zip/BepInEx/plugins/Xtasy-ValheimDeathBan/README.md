# Valheim Death Ban

Standalone permadeath mod for Valheim. When the server detects a connected player's death, it bans their account and disconnects them after a configurable delay. Creating a new character on the same account does not bypass the ban.

## Features

- Persistent account bans using Valheim's native ban list.
- Server-side death detection through the `s_dead` flag in character ZDO data, without requiring loaded player models.
- Configurable player scan interval and ban/disconnect delay.
- Admin immunity through the server's `adminlist.txt`.
- UTF-8 death journal with timestamps, character names, account IDs, raw reasons, sources and exemption status.
- Optional Discord webhook notifications, including the ban outcome.
- Global chat announcements and queued red banners using the Valheim-Norsebold font.
- Shared Russian death messages across chat, banners and Discord.
- Configurable server scan diagnostics.
- Local-world host deaths are logged; the host is always exempt from bans.
- No Jotunn, PvP Tweaks or ValheimEnforcer dependency.

## Installation

Install **BepInExPack Valheim** and this mod on the server. For manual installation, copy `ValheimDeathBan.dll` to `BepInEx/plugins/ValheimDeathBan/`.

| Installation | Available features |
| --- | --- |
| Server only | Death detection, account bans, journal, diagnostics and Discord notifications with the available reason. |
| Server and clients | Adds client death-reason reports, chat announcements and on-screen banners. |

Install the same version on the server and all clients for the full feature set. Without a client reason report, the server records an unknown reason and the public message uses the generic death sentence. The local-world host's reason is read directly.

## Configuration

Created after the first launch:

`BepInEx/config/com.xtasy.ValheimDeathBan.cfg`

```ini
[General]
Enabled = true
KickDelaySeconds = 3
BanAdmins = false
ScanIntervalSeconds = 0.25

[Announcements]
Chat = true
Banner = true
BannerSeconds = 8

[Discord]
Enabled = false
WebhookUrl =

[Diagnostics]
Enabled = true
LogIntervalMinutes = 15
```

| Setting | Default | Description |
| --- | --- | --- |
| General.Enabled | true | Enable server death processing and bans. |
| General.KickDelaySeconds | 3 | Delay after death detection before applying the ban and disconnecting. |
| General.BanAdmins | false | Exempt accounts in `adminlist.txt` when false. |
| General.ScanIntervalSeconds | 0.25 | Seconds between server scans; range 0.05–30. |
| Announcements.Chat | true | Server broadcasts shout-style chat death announcements to modded clients. |
| Announcements.Banner | true | Server broadcasts red death banners to modded clients. |
| Announcements.BannerSeconds | 8 | Banner duration on each client, clamped to 1–60 seconds. |
| Discord.Enabled | false | Enable server-side webhook notifications. |
| Discord.WebhookUrl | empty | Discord webhook URL; empty disables sending. |
| Diagnostics.Enabled | true | Enable server scan timing and periodic diagnostic logs. |
| Diagnostics.LogIntervalMinutes | 15 | Minutes between diagnostic reports; range 0.1–1440. |

Existing values are preserved when updating. If your old configuration has `BanAdmins = true`, change it to false to enable admin immunity. Immunity does not remove existing bans.

After manually editing the configuration file, restart the server or client concerned. Banner duration is a client setting; the server controls whether chat and banner announcements are broadcast.

A larger scan interval reduces check frequency but increases death-detection latency. Synchronization delay also affects detection. The disconnect delay starts when death is detected, not at the exact moment of the client's death.

## Death messages

The same Russian sentence is used in chat, the banner and the first line of Discord notifications. Character names are inserted as-is, without grammatical declension.

| Cause | Example |
| --- | --- |
| Creature attack | Древний убивает Дэнчик |
| Falling | Дэнчик разбился |
| Falling tree | Дерево придавило Дэнчик |
| Drowning | Дэнчик утонул |
| Poison | Дэнчик отравился |
| Freezing | Дэнчик замёрз |
| Fire / cinder fire | Дэнчик сгорел |
| Other or unknown causes, including PvP | Дэнчик усоп |

Creature names use available Russian localization data with fallback names for standard creatures. If a Russian name is unavailable, the message uses `Неизвестное существо`.

Chat announcements use shout-style rendering and are broadcast to all clients with the mod, without a distance restriction. Banners appear near the top of the screen in red with a black outline. Multiple deaths are queued; at most 100 banners wait in the queue, and the oldest waiting entry is dropped if it overflows. If the Norse font asset is unavailable, the game's message font is used instead.

Admin and local-host deaths are also announced. Disable overlapping death notifications in PvP Tweaks if you use both mods.

## Discord

Create a webhook for a Discord text channel and configure it **on the server**:

```ini
[Discord]
Enabled = true
WebhookUrl = https://discord.com/api/webhooks/ID/TOKEN
```

Notifications include the death sentence, account ID, death-detection timestamp with the server's time-zone offset, and ban outcome. Exempt administrators and local-world hosts are identified as exempt. Ban failures are reported as errors rather than successful bans.

The webhook URL is not synchronized to clients. Keep it private and exclude it from published packages and shared configuration files.

Delivery runs asynchronously through a bounded queue with a 10-second request timeout and limited retries for Discord rate limits. Discord errors do not prevent death logging or bans. Mentions are disabled. Pending notifications are not persisted and can be lost when the process stops. Ordinary network failures are not retried automatically to avoid uncertain duplicate deliveries.

## Death journal

`BepInEx/config/ValheimDeathBan/deaths.txt`

The append-only UTF-8 journal includes server-local timestamps with time-zone offsets, names, account IDs, raw reasons, sources and exemption flags. Public message wording does not replace the detailed reason in this file. Raw creature names may be localization keys such as `$enemy_troll`.

Admin deaths are logged even when exempt. Local-host entries use `id=local-host` and `source=local host (ban exempt)`.

## Diagnostics

Server diagnostics are written to `BepInEx/LogOutput.log`, every 15 minutes by default. Reports include:

- Last, average and maximum full-scan times in milliseconds.
- Player-list traversal times.
- Combined ZDO lookup and death-flag read times per scan.
- Scan counts, scan failures, player counts, tracked characters and lookup/read counts.

The full-scan measurement excludes the delay between scans and asynchronous Discord delivery. Previously connected characters remain tracked for up to 30 seconds, so the tracked-character count may exceed the connected-player count.

Set `Diagnostics.Enabled = false` to disable timing measurements and diagnostic reports. Death detection continues to run. The first report appears after the configured interval; statistics reset after each report and when entering a new world.

## Managing bans

Death bans use Valheim's standard `bannedlist.txt` together with administrative bans. Use the game's standard ban management to remove them. Disabling or uninstalling this mod does not remove previous bans.

Custom `deathban list`, `deathban unban` and `deathban clear` commands are not implemented in version 1.1.11.

## Detection and limitations

The server binds connected accounts to character ZDO IDs and periodically reads `s_dead`. Each detected dead character is processed once. Previous character bindings remain tracked for 30 seconds after character changes or disconnection to allow delayed synchronization. A missing ZDO is not treated as a death.

Client reports provide reasons only and do not initiate bans. However, character state still arrives through game synchronization: this mod is not an anti-cheat system or independent proof of death. Delayed or missing synchronization can delay or prevent detection.

Damage-over-time deaths may lose the original attacker. A zero-second disconnect delay may prevent a reason report from arriving in time. The local-world host is always exempt regardless of `BanAdmins`.

Targets BepInEx 5 and .NET Framework 4.7.2. Developed against supplied Valheim game assemblies; compatibility with future game versions and other mod combinations is not guaranteed.

## Русский

Банится аккаунт, а не отдельный персонаж. Мод на сервере обнаруживает смерть по `s_dead` в ZDO; модель персонажа не требуется. Клиентский мод нужен для передачи причины смерти, сообщений в чате и красного баннера.

`BanAdmins = false` даёт иммунитет администраторам из `adminlist.txt`; их смерти всё равно записываются и объявляются. Хозяин локального мира всегда освобождён от бана.

Частота проверок: `General.ScanIntervalSeconds`. Диагностика: `Diagnostics.Enabled` и `Diagnostics.LogIntervalMinutes`. Discord включается отдельно на сервере через `Discord.Enabled` и `Discord.WebhookUrl`.

Баны сохраняются в штатном `bannedlist.txt`. Журнал: `BepInEx/config/ValheimDeathBan/deaths.txt`. Команды `deathban` пока отсутствуют.
