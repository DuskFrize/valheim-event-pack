# Changelog

## 1.1.12
- Fixes

## 1.1.12

- Updated README with current features, configuration options and installation instructions.
- No code changes.

## 1.1.11

- Added server-side Discord webhook notifications with death messages, account IDs, timestamps, and ban outcomes.
- Added notifications for exempt administrators and local-world hosts.
- Added asynchronous Discord delivery with a bounded queue, request timeout, and limited rate-limit retries.
- Added death announcements in chat using the PvP Tweaks rendering approach.
- Added large red death banners using the Valheim-Norsebold font.
- Added a banner queue for multiple deaths.
- Added shared Russian death messages for creature attacks, falling, drowning, trees, poison, freezing, and fire.
- Preserved detailed death reasons in the text journal.
- Added configurable player scan intervals through General.ScanIntervalSeconds, defaulting to 0.25 seconds.
- Added diagnostic logs with the last, average, and maximum scan times, player counts, ZDO checks, and scan failures.
- Added Diagnostics.Enabled, enabled by default, and Diagnostics.LogIntervalMinutes, defaulting to 15 minutes.
- Disabling diagnostics stops timing measurements and diagnostic logs without affecting death detection.
- Preserved server-side death detection, persistent bans, admin exemptions, and the configurable disconnect delay.
- Client installation is required for chat announcements, banners, and death-reason reporting. Server-side death detection and bans continue to work without the client mod.


## 1.1.4

- Switched death detection to the s_dead flag in the server’s copy of character ZDO data.
- Added checks every 0.25 seconds without requiring player models to be loaded on the server.
- Client reports now provide death reasons only and no longer trigger bans.
- Removed reliance on Player.RPC_OnDeath for death detection.
- Added protection against processing the same death more than once.
- Previous characters remain tracked for 30 seconds after character changes or disconnection to allow delayed synchronization.
- Preserved admin exemptions, death logging, and the configurable disconnect delay.
- Client installation is no longer required for death detection. The client mod is only needed to report the cause of death.

## 1.1.2
- Added direct death journaling for local-world hosts.
- Exempted the local-world host from bans.
- Avoided peer lookup warnings for local-host deaths.

## 1.1.1
- Fixed private GetServerPeerID access using reflection.

## 1.1.0
- Added a UTF-8 death journal with timestamps, names, account IDs, reasons and exemption status.
- Added optional client reporting of death reasons and attacker names.
- Changed the default BanAdmins value to false.
- Added the UnityEngine facade reference required for building.
- Captured account IDs at death to preserve them across disconnects during the delay.

## 1.0.0
- Initial development version with native persistent account bans, configurable kick delay and admin exemption setting.
